-------------------------------
Monster Rancher 2 Helper [MR2H]
-------------------------------

----------------------------------
Installation and use instructions:
----------------------------------

***MR2H currently only works with pSX.***

1. Download pSX (http://www.emulator-zone.com/download.php/emulators/psx/psx_em/pSX_1_13.rar).
2. Extract the files in MR2 Helper.zip wherever you want, just keep the files together.
   (You don't need the source unless you want to change something or are curious.)
3. Run the emulator.
4. Run Monster Rancher 2 Helper.
   

------------------------------------------------------------------------------------------------------------
Notes: 
------------------------------------------------------------------------------------------------------------

* You don't have to do what it says, if you don't have Nuts Oil and it wants you to use Nuts Oil 
it'll adjust it's recommendations based on the actions you take.  When it recommends you do a HD, LD or Rest
it's doing so considering the current stats you have. It's not looking at what you'll have after using 
the item it recommends for this.

* When you save your monster's stats they're inputted into statlog.txt in the program's folder.
------------------------------------------------------------------------------------------------------------

---------
CHANGELOG
---------

-----
v1.0
-----

-Initial release

-----
v1.05
-----

-Added the ability to view current life stage.
-Added the ability to view current lifespan remaining in weeks
-Added the ability to set the window to always be on top.

-----
v1.06
-----

-Added the ability to edit your monster's main and sub breeds.  This monster will still have the stat gains, lifespan
and lifetype it had prior to modification but can be used in combining to make a legitimate monster.  This is just to
avoid the need to use things like PEC.

-----
v1.07a
-----

-Fixed a bug when stats got too high.

v1.1 planned features: Display stats gained per week, gold spent per week, total stats gained 
during session and eventually since monster creation and more.