1. Download pSX (http://www.emulator-zone.com/download.php/emulators/psx/psx_em/pSX_1_13.rar).
2. Extract the files in MR2 Helper.zip wherever you want, just keep the files together.  You don't need the source unless you want to change something or are curious.
3. Run the emulator.
4. Run Monster Rancher 2 Helper.